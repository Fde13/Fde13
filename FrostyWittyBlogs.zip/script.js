let primes = [2];
let currentIndex = 0;

document.body.addEventListener('click', function (event) {
    if (event.button === 0) {  // Click izquierdo
        currentIndex++;
        if (currentIndex >= primes.length) {
            primes.push(nextPrime(primes[primes.length - 1]));
        }
    } else if (event.button === 2) {  // Click derecho
        if (currentIndex > 0) {
            currentIndex--;
        }
    }
    document.getElementById('primeNumber').innerText = primes[currentIndex];
});

document.body.addEventListener('contextmenu', function (event) {
    event.preventDefault();  // Evita que aparezca el menú contextual al hacer clic derecho
});

function nextPrime(num) {
    let nextNum = num + 1;
    while (!isPrime(nextNum)) {
        nextNum++;
    }
    return nextNum;
}

function isPrime(num) {
    for (let i = 2, sqrt = Math.sqrt(num); i <= sqrt; i++) {
        if (num % i === 0) return false;
    }
    return num > 1;
}